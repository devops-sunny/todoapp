import React from 'react';

function PageNotFound() {
    return (
        <div>
            PageNotFound
        </div>
    );
}

export default PageNotFound;